package projetoFuncionario;

public class TestaFuncionario {
    
    public static void main(String [] args){
        
        // declara��o de duas variaveis do tipo Funcionario
        Funcionario f1, 
                    f2, 
                    f3;
        
        TelaFuncionario telaComum;  //declara��o de um �nica tela que ser� utilizada para cada uma das impressoes
        
        
        //Instanciar as duas variaveis criando os objetos
        f1 = new Funcionario("Jo�o da Silva", 'M', "Rua A", 100, "987.654.321-11", 2000);
        f2 = new Funcionario("Maria Aparecida", 'f', "Av. B", 200, "123.456.789-99", 20000);
        f3 = new Funcionario();
        
        telaComum = new TelaFuncionario(f1);
        
        telaComum.imprimeFuncionario();
        telaComum.imprimeSalario();
                
        telaComum.setFuncionario(f2);

        telaComum.imprimeFuncionario();
        telaComum.imprimeSalario();

        telaComum.setFuncionario(f3);
        telaComum.leNome();
        telaComum.leSexo();
        telaComum.leEndereco();
        telaComum.leCPF();
        telaComum.leSalarioBruto();

        telaComum.imprimeFuncionario();
        telaComum.imprimeEndereco();
        telaComum.imprimeSalario();

        
        
        telaComum.setFuncionario(f1);
        telaComum.imprimeFuncionario();
        telaComum.imprimeSalario();
                
        telaComum.setFuncionario(f2);
        telaComum.imprimeFuncionario();
        telaComum.imprimeSalario();

        telaComum.setFuncionario(f3);
        telaComum.imprimeFuncionario();
        telaComum.imprimeSalario();
        
    }//main()

}//class TestaFuncionario
